#include "tree.h"
#include "object.h"
#include "index.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* ------------------------------------------------------------------ */
/* Tree lifecycle                                                        */
/* ------------------------------------------------------------------ */

Tree *tree_new(void)
{
    Tree *t = calloc(1, sizeof(Tree));
    return t;
}

void tree_free(Tree *t)
{
    if (!t) return;
    free(t->entries);
    free(t);
}

int tree_add(Tree *t, unsigned int mode, const char *hash, const char *name)
{
    if (t->count >= t->capacity) {
        size_t newcap = t->capacity ? t->capacity * 2 : 8;
        TreeEntry *e = realloc(t->entries, newcap * sizeof(TreeEntry));
        if (!e) return -1;
        t->entries  = e;
        t->capacity = newcap;
    }
    TreeEntry *e = &t->entries[t->count++];
    e->mode = mode;
    strncpy(e->hash, hash, HASH_HEX - 1);
    e->hash[HASH_HEX - 1] = '\0';
    strncpy(e->name, name, MAX_PATH - 1);
    e->name[MAX_PATH - 1] = '\0';
    return 0;
}

/* ------------------------------------------------------------------ */
/* Serialization                                                         */
/* ------------------------------------------------------------------ */

static int cmp_entry(const void *a, const void *b)
{
    return strcmp(((const TreeEntry *)a)->name,
                  ((const TreeEntry *)b)->name);
}

/*
 * Binary tree format (same logic as Git):
 *
 *   For each entry (sorted by name):
 *     "<mode_octal> <name>\0<20-byte-raw-hash>"
 *
 * We store the hash as 20 raw bytes (parsed from 40 hex chars).
 */
unsigned char *tree_serialize(Tree *t, size_t *out_size)
{
    /* Sort by name for determinism */
    qsort(t->entries, t->count, sizeof(TreeEntry), cmp_entry);

    /* Calculate total size */
    size_t total = 0;
    for (size_t i = 0; i < t->count; i++) {
        char mode_str[16];
        snprintf(mode_str, sizeof(mode_str), "%o", t->entries[i].mode);
        /* "<mode> <name>\0" + 20 raw hash bytes */
        total += strlen(mode_str) + 1 + strlen(t->entries[i].name) + 1 + 20;
    }

    unsigned char *buf = malloc(total);
    if (!buf) return NULL;

    unsigned char *p = buf;
    for (size_t i = 0; i < t->count; i++) {
        TreeEntry *e = &t->entries[i];
        char mode_str[16];
        snprintf(mode_str, sizeof(mode_str), "%o", e->mode);

        /* "<mode> <name>\0" */
        size_t ms = strlen(mode_str);
        size_t ns = strlen(e->name);
        memcpy(p, mode_str, ms); p += ms;
        *p++ = ' ';
        memcpy(p, e->name, ns); p += ns;
        *p++ = '\0';

        /* 20 raw bytes from hex hash */
        for (int j = 0; j < 20; j++) {
            int hi = 0, lo = 0;
            char hc = e->hash[j*2], lc = e->hash[j*2+1];
            if (hc >= '0' && hc <= '9') hi = hc - '0';
            else if (hc >= 'a' && hc <= 'f') hi = hc - 'a' + 10;
            else if (hc >= 'A' && hc <= 'F') hi = hc - 'A' + 10;
            if (lc >= '0' && lc <= '9') lo = lc - '0';
            else if (lc >= 'a' && lc <= 'f') lo = lc - 'a' + 10;
            else if (lc >= 'A' && lc <= 'F') lo = lc - 'A' + 10;
            *p++ = (unsigned char)((hi << 4) | lo);
        }
    }

    *out_size = total;
    return buf;
}

Tree *tree_parse(const unsigned char *data, size_t size)
{
    Tree *t = tree_new();
    if (!t) return NULL;

    const unsigned char *p   = data;
    const unsigned char *end = data + size;

    while (p < end) {
        /* Read mode string up to space */
        const unsigned char *sp = memchr(p, ' ', (size_t)(end - p));
        if (!sp) break;
        char mode_str[16];
        size_t ml = (size_t)(sp - p);
        if (ml >= sizeof(mode_str)) break;
        memcpy(mode_str, p, ml);
        mode_str[ml] = '\0';
        unsigned int mode = (unsigned int)strtoul(mode_str, NULL, 8);
        p = sp + 1;

        /* Read name up to NUL */
        const unsigned char *nul = memchr(p, '\0', (size_t)(end - p));
        if (!nul) break;
        char name[MAX_PATH];
        size_t nl = (size_t)(nul - p);
        if (nl >= MAX_PATH) break;
        memcpy(name, p, nl);
        name[nl] = '\0';
        p = nul + 1;

        /* Read 20 raw hash bytes */
        if (p + 20 > end) break;
        char hex[HASH_HEX];
        static const char digits[] = "0123456789abcdef";
        for (int j = 0; j < 20; j++) {
            hex[j*2]     = digits[(p[j] >> 4) & 0xf];
            hex[j*2 + 1] = digits[p[j] & 0xf];
        }
        hex[40] = '\0';
        p += 20;

        tree_add(t, mode, hex, name);
    }

    return t;
}

/* ------------------------------------------------------------------ */
/* tree_from_index — build tree hierarchy from the index               */
/* ------------------------------------------------------------------ */

/*
 * Strategy:
 *   The index has entries like:
 *     100644 <hash> <mtime> <size> src/foo/bar.c
 *
 *   We need to turn this into nested tree objects.
 *   Simple recursive approach:
 *     - collect all unique first path components
 *     - files at this level → add as blob entries
 *     - directories → recurse, write sub-tree, add as tree entry
 *
 *   We pass a "prefix" to filter index entries that belong to this
 *   sub-tree.
 */

/* Write a tree built from index entries whose path starts with prefix.
 * prefix = "" means root.
 * Returns 0 on success. */
static int write_subtree(Index *idx, const char *prefix, char out_hex[HASH_HEX])
{
    Tree *t = tree_new();
    if (!t) return -1;

    size_t prefix_len = strlen(prefix);

    /* Collect unique first-level names under this prefix */
    /* We'll iterate index entries and sort out files vs subdirs */

    /* Use a visited array to avoid duplicate directory entries */
    char seen_dirs[MAX_ENTRIES][MAX_PATH];
    int  seen_count = 0;

    for (size_t i = 0; i < idx->count; i++) {
        IndexEntry *e = &idx->entries[i];
        const char *path = e->path;

        /* Does this entry live under our prefix? */
        if (prefix_len > 0) {
            if (strncmp(path, prefix, prefix_len) != 0) continue;
            if (path[prefix_len] != '/') continue;
            path = path + prefix_len + 1;  /* strip prefix/ */
        }

        /* Is there a slash in the remaining path? */
        const char *slash = strchr(path, '/');
        if (slash == NULL) {
            /* Direct file entry at this level */
            tree_add(t, e->mode, e->hash, path);
        } else {
            /* This is a subdirectory entry */
            char dirname[MAX_PATH];
            size_t dlen = (size_t)(slash - path);
            memcpy(dirname, path, dlen);
            dirname[dlen] = '\0';

            /* Skip if we've already processed this dir */
            int already = 0;
            for (int j = 0; j < seen_count; j++) {
                if (strcmp(seen_dirs[j], dirname) == 0) { already = 1; break; }
            }
            if (already) continue;

            /* Recurse to build the sub-tree */
            char sub_prefix[MAX_PATH];
            if (prefix_len > 0)
                snprintf(sub_prefix, sizeof(sub_prefix), "%s/%s", prefix, dirname);
            else
                strncpy(sub_prefix, dirname, sizeof(sub_prefix) - 1);

            char sub_hex[HASH_HEX];
            if (write_subtree(idx, sub_prefix, sub_hex) < 0) {
                tree_free(t);
                return -1;
            }

            tree_add(t, MODE_DIR, sub_hex, dirname);

            /* Mark as seen */
            if (seen_count < MAX_ENTRIES)
                strncpy(seen_dirs[seen_count++], dirname, MAX_PATH - 1);
        }
    }

    /* Serialize and write the tree object */
    size_t sz;
    unsigned char *raw = tree_serialize(t, &sz);
    tree_free(t);
    if (!raw) return -1;

    int ret = object_write(OBJ_TREE, raw, sz, out_hex);
    free(raw);
    return ret;
}

int tree_from_index(char out_hex[HASH_HEX])
{
    Index idx;
    if (index_load(&idx) < 0) return -1;

    int ret = write_subtree(&idx, "", out_hex);
    index_free(&idx);
    return ret;
}
