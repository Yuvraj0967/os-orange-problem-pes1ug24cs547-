#define _POSIX_C_SOURCE 200809L
#define _XOPEN_SOURCE   700

#include "index.h"
#include "object.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>

/* ------------------------------------------------------------------ */
/* Internal helpers                                                      */
/* ------------------------------------------------------------------ */

static int index_grow(Index *idx)
{
    if (idx->count < idx->capacity) return 0;
    size_t newcap = idx->capacity ? idx->capacity * 2 : 16;
    IndexEntry *e = realloc(idx->entries, newcap * sizeof(IndexEntry));
    if (!e) return -1;
    idx->entries  = e;
    idx->capacity = newcap;
    return 0;
}

static int cmp_by_path(const void *a, const void *b)
{
    return strcmp(((const IndexEntry *)a)->path,
                  ((const IndexEntry *)b)->path);
}

/* ------------------------------------------------------------------ */
/* PROVIDED functions                                                    */
/* ------------------------------------------------------------------ */

IndexEntry *index_find(Index *idx, const char *path)
{
    for (size_t i = 0; i < idx->count; i++)
        if (strcmp(idx->entries[i].path, path) == 0)
            return &idx->entries[i];
    return NULL;
}

void index_remove(Index *idx, const char *path)
{
    for (size_t i = 0; i < idx->count; i++) {
        if (strcmp(idx->entries[i].path, path) == 0) {
            /* Shift remaining entries left */
            memmove(&idx->entries[i], &idx->entries[i+1],
                    (idx->count - i - 1) * sizeof(IndexEntry));
            idx->count--;
            return;
        }
    }
}

FileStatus index_status(Index *idx, const char *path)
{
    IndexEntry *e = index_find(idx, path);
    struct stat st;
    int exists = (stat(path, &st) == 0);

    if (!e) return STATUS_UNTRACKED;
    if (!exists) return STATUS_DELETED;

    /* Compare mtime and size as a fast check */
    if ((time_t)st.st_mtime == e->mtime && (size_t)st.st_size == e->size)
        return STATUS_STAGED;  /* likely unchanged */
    return STATUS_MODIFIED;
}

/* ------------------------------------------------------------------ */
/* index_load                                                            */
/* ------------------------------------------------------------------ */

/*
 * Format (one line per entry):
 *   <mode_octal> <hash_hex> <mtime> <size> <path>
 *
 * Example:
 *   100644 a1b2c3... 1699900000 42 src/main.c
 */
int index_load(Index *idx)
{
    memset(idx, 0, sizeof(*idx));

    FILE *f = fopen(INDEX_FILE, "r");
    if (!f) {
        if (errno == ENOENT) return 0;  /* no index yet — OK */
        return -1;
    }

    char line[MAX_PATH + 128];
    while (fgets(line, sizeof(line), f)) {
        /* Strip trailing newline */
        size_t len = strlen(line);
        while (len > 0 && (line[len-1] == '\n' || line[len-1] == '\r'))
            line[--len] = '\0';
        if (len == 0) continue;

        if (index_grow(idx) < 0) { fclose(f); return -1; }
        IndexEntry *e = &idx->entries[idx->count];

        unsigned long mode, mtime, size;
        char hash[HASH_HEX];
        char path[MAX_PATH];

        if (sscanf(line, "%lo %64s %lu %lu %4095s",
                   &mode, hash, &mtime, &size, path) != 5)
            continue;

        e->mode  = (unsigned int)mode;
        strncpy(e->hash, hash, HASH_HEX - 1);
        e->hash[HASH_HEX - 1] = '\0';
        e->mtime = (time_t)mtime;
        e->size  = (size_t)size;
        strncpy(e->path, path, MAX_PATH - 1);
        e->path[MAX_PATH - 1] = '\0';
        idx->count++;
    }

    fclose(f);
    return 0;
}

/* ------------------------------------------------------------------ */
/* index_save                                                            */
/* ------------------------------------------------------------------ */

int index_save(const Index *idx)
{
    /* Sort a copy */
    Index sorted = *idx;
    IndexEntry *copy = malloc(sorted.count * sizeof(IndexEntry));
    if (!copy && sorted.count > 0) return -1;
    if (copy) memcpy(copy, sorted.entries, sorted.count * sizeof(IndexEntry));
    sorted.entries = copy;
    qsort(sorted.entries, sorted.count, sizeof(IndexEntry), cmp_by_path);

    /* Write to temp file */
    char tmp[MAX_PATH];
    snprintf(tmp, sizeof(tmp), "%s/.index_tmp_XXXXXX", PES_DIR);
    int fd = mkstemp(tmp);
    if (fd < 0) { free(copy); return -1; }

    FILE *f = fdopen(fd, "w");
    if (!f) { close(fd); unlink(tmp); free(copy); return -1; }

    for (size_t i = 0; i < sorted.count; i++) {
        IndexEntry *e = &sorted.entries[i];
        fprintf(f, "%o %s %lu %zu %s\n",
                e->mode, e->hash,
                (unsigned long)e->mtime,
                e->size,
                e->path);
    }

    fflush(f);
    fsync(fileno(f));
    fclose(f);
    free(copy);

    if (rename(tmp, INDEX_FILE) < 0) { unlink(tmp); return -1; }
    return 0;
}

/* ------------------------------------------------------------------ */
/* index_add                                                             */
/* ------------------------------------------------------------------ */

int index_add(Index *idx, const char *path)
{
    /* Stat the file */
    struct stat st;
    if (stat(path, &st) < 0) {
        fprintf(stderr, "pes: cannot stat '%s': %s\n", path, strerror(errno));
        return -1;
    }

    /* Read file contents */
    FILE *f = fopen(path, "rb");
    if (!f) {
        fprintf(stderr, "pes: cannot open '%s': %s\n", path, strerror(errno));
        return -1;
    }
    fseek(f, 0, SEEK_END);
    long fsz = ftell(f);
    fseek(f, 0, SEEK_SET);

    unsigned char *data = malloc(fsz > 0 ? (size_t)fsz : 1);
    if (!data) { fclose(f); return -1; }
    size_t nread = fread(data, 1, (size_t)fsz, f);
    fclose(f);

    /* Write blob to object store */
    char hash[HASH_HEX];
    if (object_write(OBJ_BLOB, data, nread, hash) < 0) {
        free(data);
        return -1;
    }
    free(data);

    /* Determine mode */
    unsigned int mode = (st.st_mode & S_IXUSR) ? MODE_EXEC : MODE_FILE;

    /* Update or insert index entry */
    IndexEntry *e = index_find(idx, path);
    if (!e) {
        if (index_grow(idx) < 0) return -1;
        e = &idx->entries[idx->count++];
    }

    e->mode  = mode;
    strncpy(e->hash, hash, HASH_HEX - 1);
    e->hash[HASH_HEX - 1] = '\0';
    e->mtime = st.st_mtime;
    e->size  = (size_t)st.st_size;
    strncpy(e->path, path, MAX_PATH - 1);
    e->path[MAX_PATH - 1] = '\0';

    return 0;
}

/* ------------------------------------------------------------------ */
/* index_free                                                            */
/* ------------------------------------------------------------------ */

void index_free(Index *idx)
{
    free(idx->entries);
    memset(idx, 0, sizeof(*idx));
}
