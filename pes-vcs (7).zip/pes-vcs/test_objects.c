/*
 * test_objects.c — Phase 1 test: object store
 * PROVIDED — do not modify.
 */

#include "pes.h"
#include "object.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>

static int passed = 0;
static int failed = 0;

static void check(const char *name, int ok)
{
    if (ok) {
        printf("  PASS  %s\n", name);
        passed++;
    } else {
        printf("  FAIL  %s\n", name);
        failed++;
    }
}

int main(void)
{
    printf("=== Phase 1: Object Storage ===\n\n");

    /* Need a .pes/objects directory */
    mkdir(".pes", 0755);
    mkdir(".pes/objects", 0755);

    /* --- Test 1: write and read a blob --- */
    printf("Test 1: blob write/read\n");
    const char *content = "Hello, PES-VCS!\n";
    size_t clen = strlen(content);
    char hex1[HASH_HEX];

    int ok = (object_write("blob", (const unsigned char *)content, clen, hex1) == 0);
    check("object_write returns 0", ok);
    check("hex is 64 chars", strlen(hex1) == 64);

    /* Read it back */
    char type1[16];
    size_t sz1;
    unsigned char *back = object_read(hex1, type1, &sz1);
    check("object_read returns non-NULL", back != NULL);
    if (back) {
        check("type is 'blob'", strcmp(type1, "blob") == 0);
        check("size matches", sz1 == clen);
        check("content matches", memcmp(back, content, clen) == 0);
        free(back);
    }

    /* --- Test 2: deduplication --- */
    printf("\nTest 2: deduplication\n");
    char hex2[HASH_HEX];
    object_write("blob", (const unsigned char *)content, clen, hex2);
    check("same content → same hash", strcmp(hex1, hex2) == 0);

    /* --- Test 3: different content → different hash --- */
    printf("\nTest 3: different content\n");
    const char *content2 = "Different content!\n";
    char hex3[HASH_HEX];
    object_write("blob", (const unsigned char *)content2, strlen(content2), hex3);
    check("different content → different hash", strcmp(hex1, hex3) != 0);

    /* --- Test 4: integrity check (corrupt the object) --- */
    printf("\nTest 4: integrity check\n");
    char path[MAX_PATH];
    object_path(hex3, path, sizeof(path));

    /* Corrupt one byte */
    FILE *f = fopen(path, "r+b");
    if (f) {
        fseek(f, 10, SEEK_SET);
        fputc('X', f);
        fclose(f);
    }

    char type4[16];
    size_t sz4;
    unsigned char *corrupt = object_read(hex3, type4, &sz4);
    check("corrupted object returns NULL", corrupt == NULL);
    free(corrupt);  /* safe to free(NULL) */

    /* --- Test 5: commit object --- */
    printf("\nTest 5: commit object type\n");
    const char *cmsg = "tree abc123\nauthor Test\n\nFirst commit\n";
    char hex5[HASH_HEX];
    object_write("commit", (const unsigned char *)cmsg, strlen(cmsg), hex5);
    char type5[16];
    size_t sz5;
    unsigned char *cdata = object_read(hex5, type5, &sz5);
    check("commit type preserved", cdata && strcmp(type5, "commit") == 0);
    free(cdata);

    /* --- Summary --- */
    printf("\n=== Results: %d passed, %d failed ===\n", passed, failed);
    return failed > 0 ? 1 : 0;
}
