#ifndef INDEX_H
#define INDEX_H

#include "pes.h"
#include <stddef.h>
#include <time.h>

/* One staged file */
typedef struct {
    unsigned int mode;
    char         hash[HASH_HEX];
    time_t       mtime;
    size_t       size;
    char         path[MAX_PATH];
} IndexEntry;

/* The staging area */
typedef struct {
    IndexEntry *entries;
    size_t      count;
    size_t      capacity;
} Index;

/* Status of a file relative to the index and HEAD */
typedef enum {
    STATUS_STAGED,      /* in index, not in HEAD (new file staged) */
    STATUS_MODIFIED,    /* in working dir, differs from index */
    STATUS_DELETED,     /* in index, missing from working dir */
    STATUS_UNTRACKED,   /* not in index at all */
} FileStatus;

/* Load .pes/index into idx. Returns 0 on success (empty index is OK). */
int   index_load(Index *idx);

/* Save idx to .pes/index atomically. Returns 0 on success. */
int   index_save(const Index *idx);

/* Stage a single file. Returns 0 on success. */
int   index_add(Index *idx, const char *path);

/* Free memory held by idx (does not write to disk). */
void  index_free(Index *idx);

/* PROVIDED — find an entry by path, or NULL */
IndexEntry *index_find(Index *idx, const char *path);

/* PROVIDED — remove an entry by path */
void index_remove(Index *idx, const char *path);

/* PROVIDED — compute status of a path */
FileStatus index_status(Index *idx, const char *path);

#endif /* INDEX_H */
