#ifndef COMMIT_H
#define COMMIT_H

#include "pes.h"
#include <time.h>

/* Parsed commit object */
typedef struct {
    char   tree[HASH_HEX];
    char   parent[HASH_HEX];   /* empty string if no parent */
    char   author[256];
    time_t timestamp;
    char   message[4096];
} Commit;

/*
 * commit_create — Build tree from index, write commit object, update HEAD.
 * Returns 0 on success, -1 on error.
 */
int commit_create(const char *message);

/* PROVIDED — parse raw commit bytes into a Commit struct */
Commit *commit_parse(const unsigned char *data, size_t size);

/* PROVIDED — serialize a Commit struct to bytes. Caller must free(). */
unsigned char *commit_serialize(const Commit *c, size_t *out_size);

/* PROVIDED — walk and print commit history from HEAD */
void commit_walk(void);

/* PROVIDED — read current HEAD commit hash (empty string if no commits) */
int head_read(char out_hex[HASH_HEX]);

/* PROVIDED — write a new commit hash to the current branch ref */
int head_update(const char *hex);

#endif /* COMMIT_H */
