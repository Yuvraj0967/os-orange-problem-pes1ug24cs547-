#!/usr/bin/env bash
# test_sequence.sh — End-to-end integration test
set -e

echo "=== PES-VCS Integration Test ==="

# Clean up
rm -rf .pes test_dir
mkdir test_dir && cd test_dir

# Copy the pes binary
cp ../pes .

export PES_AUTHOR="Test User <PESTEST001>"

echo "--- init ---"
./pes init
test -d .pes && echo "PASS: .pes directory created"
test -f .pes/HEAD && echo "PASS: HEAD file exists"

echo "--- add + commit 1 ---"
echo "Hello, world!" > hello.txt
echo "Makefile stuff" > Makefile
./pes add hello.txt Makefile
./pes status
./pes commit -m "Initial commit"
./pes log | grep -q "Initial commit" && echo "PASS: commit 1 in log"

echo "--- commit 2 ---"
echo "More content" >> hello.txt
mkdir -p src
echo 'int main(){return 0;}' > src/main.c
./pes add hello.txt src/main.c
./pes commit -m "Add source file"
./pes log | grep -q "Add source file" && echo "PASS: commit 2 in log"

echo "--- commit 3 ---"
echo "Goodbye" > bye.txt
./pes add bye.txt
./pes commit -m "Add farewell"
./pes log | grep -q "Add farewell" && echo "PASS: commit 3 in log"

echo "--- verify object store ---"
COUNT=$(find .pes/objects -type f | wc -l)
echo "Object store has $COUNT objects"
test "$COUNT" -ge 6 && echo "PASS: sufficient objects stored"

echo "--- verify HEAD chain ---"
cat .pes/HEAD
cat .pes/refs/heads/main

cd ..
rm -rf test_dir
echo ""
echo "=== Integration test PASSED ==="
