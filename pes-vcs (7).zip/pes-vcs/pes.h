#ifndef PES_H
#define PES_H

#include <stddef.h>
#include <stdint.h>
#include <time.h>

/* SHA-256 produces 32 bytes = 64 hex characters */
#define HASH_SIZE   32
#define HASH_HEX    65   /* 64 hex chars + NUL */

/* Object types */
#define OBJ_BLOB    "blob"
#define OBJ_TREE    "tree"
#define OBJ_COMMIT  "commit"

/* Repository directory */
#define PES_DIR     ".pes"
#define OBJECTS_DIR ".pes/objects"
#define REFS_DIR    ".pes/refs/heads"
#define HEAD_FILE   ".pes/HEAD"
#define INDEX_FILE  ".pes/index"
#define MAIN_BRANCH "main"

/* File modes (same as Git) */
#define MODE_FILE   0100644
#define MODE_EXEC   0100755
#define MODE_DIR    0040000

/* Max sizes */
#define MAX_PATH    4096
#define MAX_ENTRIES 4096

/* Returns the author string from PES_AUTHOR env var, or a default. */
const char *pes_author(void);

#endif /* PES_H */
