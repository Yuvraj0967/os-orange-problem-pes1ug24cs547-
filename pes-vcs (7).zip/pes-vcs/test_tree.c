/*
 * test_tree.c — Phase 2 test: tree objects
 * PROVIDED — do not modify.
 */

#include "pes.h"
#include "object.h"
#include "tree.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>

static int passed = 0;
static int failed = 0;

static void check(const char *name, int ok)
{
    if (ok) {
        printf("  PASS  %s\n", name);
        passed++;
    } else {
        printf("  FAIL  %s\n", name);
        failed++;
    }
}

int main(void)
{
    printf("=== Phase 2: Tree Objects ===\n\n");

    mkdir(".pes", 0755);
    mkdir(".pes/objects", 0755);

    /* Build a small tree */
    Tree *t = tree_new();
    check("tree_new", t != NULL);

    /* Add entries in non-alphabetical order to test sorting */
    tree_add(t, MODE_FILE,
             "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
             "zebra.txt");
    tree_add(t, MODE_EXEC,
             "bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb",
             "apple.sh");
    tree_add(t, MODE_DIR,
             "cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc",
             "mango");

    /* --- Test 1: serialize → parse roundtrip --- */
    printf("Test 1: serialize/parse roundtrip\n");
    size_t sz;
    unsigned char *raw = tree_serialize(t, &sz);
    check("serialize returns non-NULL", raw != NULL);
    check("serialize size > 0", sz > 0);

    Tree *t2 = tree_parse(raw, sz);
    check("parse returns non-NULL", t2 != NULL);
    if (t2) {
        check("entry count preserved", t2->count == t->count);

        /* After serialize, entries are sorted. Verify sort. */
        if (t2->count == 3) {
            check("sorted: apple first",  strcmp(t2->entries[0].name, "apple.sh") == 0);
            check("sorted: mango second", strcmp(t2->entries[1].name, "mango") == 0);
            check("sorted: zebra last",   strcmp(t2->entries[2].name, "zebra.txt") == 0);

            check("apple mode = exec",    t2->entries[0].mode == MODE_EXEC);
            check("mango mode = dir",     t2->entries[1].mode == MODE_DIR);
            check("zebra mode = file",    t2->entries[2].mode == MODE_FILE);

            check("apple hash preserved",
                  strncmp(t2->entries[0].hash,
                          "bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb",
                          64) == 0);
        }
        tree_free(t2);
    }

    /* --- Test 2: deterministic serialization --- */
    printf("\nTest 2: deterministic serialization\n");
    Tree *t3 = tree_new();
    /* Add in different order */
    tree_add(t3, MODE_DIR,
             "cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc",
             "mango");
    tree_add(t3, MODE_FILE,
             "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
             "zebra.txt");
    tree_add(t3, MODE_EXEC,
             "bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb",
             "apple.sh");

    size_t sz3;
    unsigned char *raw3 = tree_serialize(t3, &sz3);
    check("same entries different order → same size",   sz == sz3);
    check("same entries different order → same bytes",
          sz == sz3 && raw && raw3 && memcmp(raw, raw3, sz) == 0);

    /* --- Test 3: write to object store --- */
    printf("\nTest 3: write to object store\n");
    char hex[HASH_HEX];
    int wr = object_write(OBJ_TREE, raw, sz, hex);
    check("object_write succeeds", wr == 0);
    check("hex is 64 chars", strlen(hex) == 64);

    char type_back[16];
    size_t sz_back;
    unsigned char *back = object_read(hex, type_back, &sz_back);
    check("read back non-NULL", back != NULL);
    check("type is 'tree'", back && strcmp(type_back, "tree") == 0);
    check("content matches", back && sz_back == sz && memcmp(back, raw, sz) == 0);

    free(back);
    free(raw);
    free(raw3);
    tree_free(t);
    tree_free(t3);

    printf("\n=== Results: %d passed, %d failed ===\n", passed, failed);
    return failed > 0 ? 1 : 0;
}
