#define _POSIX_C_SOURCE 200809L
#define _XOPEN_SOURCE   700

#include "object.h"
#include "pes.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>
#include <unistd.h>
#include <openssl/sha.h>

/* ------------------------------------------------------------------ */
/* Helpers                                                              */
/* ------------------------------------------------------------------ */

static void bytes_to_hex(const unsigned char *bytes, int len, char *hex)
{
    static const char digits[] = "0123456789abcdef";
    for (int i = 0; i < len; i++) {
        hex[i*2]     = digits[(bytes[i] >> 4) & 0xf];
        hex[i*2 + 1] = digits[bytes[i] & 0xf];
    }
    hex[len*2] = '\0';
}

static int hex_to_byte(char c)
{
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    if (c >= 'A' && c <= 'F') return c - 'A' + 10;
    return -1;
}

/* mkdir -p for a single path (modifies path in-place temporarily) */
static int mkdirp(char *path)
{
    for (char *p = path + 1; *p; p++) {
        if (*p == '/') {
            *p = '\0';
            if (mkdir(path, 0755) < 0 && errno != EEXIST) {
                *p = '/';
                return -1;
            }
            *p = '/';
        }
    }
    if (mkdir(path, 0755) < 0 && errno != EEXIST)
        return -1;
    return 0;
}

/* ------------------------------------------------------------------ */
/* Public API                                                           */
/* ------------------------------------------------------------------ */

void object_path(const char *hex, char *buf, size_t buflen)
{
    /* .pes/objects/XX/YYYY... */
    snprintf(buf, buflen, "%s/%.2s/%s", OBJECTS_DIR, hex, hex + 2);
}

/*
 * object_write
 *
 * Steps:
 *  1. Build the header:  "<type> <size>\0"
 *  2. Concatenate header + data into one buffer
 *  3. SHA-256 hash that buffer → get hex path
 *  4. If object already exists, skip writing (deduplication)
 *  5. mkdir -p the shard directory
 *  6. Write to a temp file in the same directory, then rename (atomic)
 */
int object_write(const char *type, const unsigned char *data, size_t size,
                 char out_hex[HASH_HEX])
{
    /* --- 1. Build header --- */
    char header[64];
    int hlen = snprintf(header, sizeof(header), "%s %zu", type, size);
    /* hlen does NOT include the NUL; we need the NUL in the object */
    size_t full_size = (size_t)hlen + 1 + size;  /* header + '\0' + data */

    /* --- 2. Assemble full object in memory --- */
    unsigned char *full = malloc(full_size);
    if (!full) return -1;
    memcpy(full, header, hlen);
    full[hlen] = '\0';
    memcpy(full + hlen + 1, data, size);

    /* --- 3. SHA-256 --- */
    unsigned char hash[HASH_SIZE];
    SHA256(full, full_size, hash);
    bytes_to_hex(hash, HASH_SIZE, out_hex);

    /* --- 4. Check for existing object --- */
    char path[MAX_PATH];
    object_path(out_hex, path, sizeof(path));
    if (access(path, F_OK) == 0) {
        free(full);
        return 0;   /* already stored — deduplication */
    }

    /* --- 5. Ensure shard directory exists --- */
    char dir[MAX_PATH];
    snprintf(dir, sizeof(dir), "%s/%.2s", OBJECTS_DIR, out_hex);
    if (mkdirp(dir) < 0) { free(full); return -1; }

    /* --- 6. Write via temp file + rename (atomic) --- */
    char tmp[MAX_PATH];
    snprintf(tmp, sizeof(tmp), "%s/.tmp_XXXXXX", dir);
    int fd = mkstemp(tmp);
    if (fd < 0) { free(full); return -1; }

    size_t written = 0;
    while (written < full_size) {
        ssize_t n = write(fd, full + written, full_size - written);
        if (n < 0) {
            close(fd); unlink(tmp); free(full);
            return -1;
        }
        written += (size_t)n;
    }

    if (fsync(fd) < 0) { close(fd); unlink(tmp); free(full); return -1; }
    close(fd);
    free(full);

    if (rename(tmp, path) < 0) { unlink(tmp); return -1; }
    return 0;
}

/*
 * object_read
 *
 * Steps:
 *  1. Build path from hex, open and read the file
 *  2. Re-compute SHA-256 and compare to filename (integrity check)
 *  3. Parse header: "<type> <size>\0"
 *  4. Return data portion (after the '\0')
 */
unsigned char *object_read(const char *hex, char out_type[16], size_t *out_size)
{
    /* --- 1. Read file --- */
    char path[MAX_PATH];
    object_path(hex, path, sizeof(path));

    FILE *f = fopen(path, "rb");
    if (!f) return NULL;

    fseek(f, 0, SEEK_END);
    long fsize = ftell(f);
    fseek(f, 0, SEEK_SET);
    if (fsize <= 0) { fclose(f); return NULL; }

    unsigned char *raw = malloc((size_t)fsize);
    if (!raw) { fclose(f); return NULL; }

    if ((long)fread(raw, 1, (size_t)fsize, f) != fsize) {
        free(raw); fclose(f); return NULL;
    }
    fclose(f);

    /* --- 2. Integrity check --- */
    unsigned char hash[HASH_SIZE];
    SHA256(raw, (size_t)fsize, hash);
    char actual_hex[HASH_HEX];
    bytes_to_hex(hash, HASH_SIZE, actual_hex);
    if (strncmp(actual_hex, hex, HASH_HEX - 1) != 0) {
        fprintf(stderr, "object_read: hash mismatch for %s\n", hex);
        free(raw);
        return NULL;
    }

    /* --- 3. Parse header "<type> <size>\0" --- */
    /* Find the space */
    unsigned char *sp = memchr(raw, ' ', (size_t)fsize);
    if (!sp) { free(raw); return NULL; }
    /* Find the NUL after the size */
    unsigned char *nul = memchr(sp + 1, '\0', (size_t)(fsize - (sp - raw + 1)));
    if (!nul) { free(raw); return NULL; }

    size_t type_len = (size_t)(sp - raw);
    if (type_len > 15) { free(raw); return NULL; }
    memcpy(out_type, raw, type_len);
    out_type[type_len] = '\0';

    size_t data_size = (size_t)atol((char *)(sp + 1));
    *out_size = data_size;

    /* --- 4. Return a copy of the data portion --- */
    unsigned char *data_start = nul + 1;
    unsigned char *result = malloc(data_size + 1);
    if (!result) { free(raw); return NULL; }
    memcpy(result, data_start, data_size);
    result[data_size] = '\0';   /* convenient NUL for string objects */

    free(raw);
    return result;
}
