#ifndef TREE_H
#define TREE_H

#include "pes.h"
#include <stddef.h>

/* One entry in a tree object */
typedef struct {
    unsigned int mode;          /* MODE_FILE, MODE_EXEC, or MODE_DIR */
    char hash[HASH_HEX];        /* hex hash of blob or sub-tree */
    char name[MAX_PATH];        /* filename (not full path) */
} TreeEntry;

/* A tree object (directory snapshot) */
typedef struct {
    TreeEntry *entries;
    size_t     count;
    size_t     capacity;
} Tree;

/* Lifecycle */
Tree  *tree_new(void);
void   tree_free(Tree *t);
int    tree_add(Tree *t, unsigned int mode, const char *hash, const char *name);

/*
 * tree_serialize — Convert a Tree to the raw binary format used in the
 * object store.  Caller must free() the returned buffer.
 * Entries are sorted by name before serialization.
 */
unsigned char *tree_serialize(Tree *t, size_t *out_size);

/*
 * tree_parse — Deserialize raw bytes back into a Tree.
 * Returns NULL on error.
 */
Tree *tree_parse(const unsigned char *data, size_t size);

/*
 * tree_from_index — Build the full directory tree from the current index
 * and write all tree objects to the object store.
 * out_hex receives the root tree hash.
 * Returns 0 on success, -1 on error.
 */
int tree_from_index(char out_hex[HASH_HEX]);

#endif /* TREE_H */
