#define _POSIX_C_SOURCE 200809L
#define _XOPEN_SOURCE   700

/*
 * commit.c — Commit creation and history walking.
 *
 * Commit text format (stored as object of type "commit"):
 *
 *   tree <tree-hex>\n
 *   [parent <parent-hex>\n]       <- omitted for root commit
 *   author <author-string> <unix-timestamp>\n
 *   committer <author-string> <unix-timestamp>\n
 *   \n
 *   <message>\n
 */

#include "commit.h"
#include "tree.h"
#include "object.h"
#include "index.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <errno.h>
#include <sys/stat.h>

/* ------------------------------------------------------------------ */
/* PROVIDED: head_read                                                   */
/* ------------------------------------------------------------------ */

int head_read(char out_hex[HASH_HEX])
{
    out_hex[0] = '\0';

    /* Read HEAD to find which branch we're on */
    FILE *hf = fopen(HEAD_FILE, "r");
    if (!hf) return -1;
    char head_content[256];
    if (!fgets(head_content, sizeof(head_content), hf)) {
        fclose(hf); return -1;
    }
    fclose(hf);

    /* Strip newline */
    head_content[strcspn(head_content, "\r\n")] = '\0';

    char ref_path[MAX_PATH];
    if (strncmp(head_content, "ref: ", 5) == 0) {
        /* Symbolic ref: "ref: refs/heads/main" */
        snprintf(ref_path, sizeof(ref_path), "%s/%s", PES_DIR, head_content + 5);
    } else {
        /* Detached HEAD: content is already a hash */
        strncpy(out_hex, head_content, HASH_HEX - 1);
        out_hex[HASH_HEX - 1] = '\0';
        return 0;
    }

    FILE *rf = fopen(ref_path, "r");
    if (!rf) {
        if (errno == ENOENT) return 0;  /* no commits yet */
        return -1;
    }
    if (!fgets(out_hex, HASH_HEX, rf)) { fclose(rf); out_hex[0] = '\0'; return 0; }
    fclose(rf);
    out_hex[strcspn(out_hex, "\r\n")] = '\0';
    return 0;
}

/* ------------------------------------------------------------------ */
/* PROVIDED: head_update                                                 */
/* ------------------------------------------------------------------ */

int head_update(const char *hex)
{
    /* Read HEAD to find the branch ref path */
    FILE *hf = fopen(HEAD_FILE, "r");
    if (!hf) return -1;
    char head_content[256];
    if (!fgets(head_content, sizeof(head_content), hf)) {
        fclose(hf); return -1;
    }
    fclose(hf);
    head_content[strcspn(head_content, "\r\n")] = '\0';

    char ref_path[MAX_PATH];
    if (strncmp(head_content, "ref: ", 5) == 0) {
        snprintf(ref_path, sizeof(ref_path), "%s/%s", PES_DIR, head_content + 5);
    } else {
        /* Detached HEAD — update HEAD directly */
        strncpy(ref_path, HEAD_FILE, sizeof(ref_path) - 1);
    }

    /* Ensure directory exists */
    char dir[MAX_PATH];
    strncpy(dir, ref_path, sizeof(dir) - 1);
    char *slash = strrchr(dir, '/');
    if (slash) {
        *slash = '\0';
        mkdir(dir, 0755);
    }

    /* Write atomically */
    char tmp[MAX_PATH];
    snprintf(tmp, sizeof(tmp), "%s.tmp", ref_path);
    FILE *f = fopen(tmp, "w");
    if (!f) return -1;
    fprintf(f, "%s\n", hex);
    fflush(f);
    fclose(f);
    if (rename(tmp, ref_path) < 0) { unlink(tmp); return -1; }
    return 0;
}

/* ------------------------------------------------------------------ */
/* PROVIDED: commit_serialize                                            */
/* ------------------------------------------------------------------ */

unsigned char *commit_serialize(const Commit *c, size_t *out_size)
{
    char buf[8192];
    int  n = 0;

    n += snprintf(buf + n, sizeof(buf) - n, "tree %s\n", c->tree);
    if (c->parent[0])
        n += snprintf(buf + n, sizeof(buf) - n, "parent %s\n", c->parent);
    n += snprintf(buf + n, sizeof(buf) - n,
                  "author %s %ld\n", c->author, (long)c->timestamp);
    n += snprintf(buf + n, sizeof(buf) - n,
                  "committer %s %ld\n", c->author, (long)c->timestamp);
    n += snprintf(buf + n, sizeof(buf) - n, "\n%s\n", c->message);

    *out_size = (size_t)n;
    unsigned char *result = malloc((size_t)n + 1);
    if (!result) return NULL;
    memcpy(result, buf, (size_t)n + 1);
    return result;
}

/* ------------------------------------------------------------------ */
/* PROVIDED: commit_parse                                                */
/* ------------------------------------------------------------------ */

Commit *commit_parse(const unsigned char *data, size_t size)
{
    Commit *c = calloc(1, sizeof(Commit));
    if (!c) return NULL;

    /* Work on a NUL-terminated copy */
    char *buf = malloc(size + 1);
    if (!buf) { free(c); return NULL; }
    memcpy(buf, data, size);
    buf[size] = '\0';

    char *p = buf;
    while (*p) {
        char *eol = strchr(p, '\n');
        if (!eol) break;
        *eol = '\0';

        if (strncmp(p, "tree ", 5) == 0) {
            strncpy(c->tree, p + 5, HASH_HEX - 1);
        } else if (strncmp(p, "parent ", 7) == 0) {
            strncpy(c->parent, p + 7, HASH_HEX - 1);
        } else if (strncmp(p, "author ", 7) == 0) {
            /* "author <name> <timestamp>" — parse from right */
            char *ts = strrchr(p + 7, ' ');
            if (ts) {
                c->timestamp = (time_t)atol(ts + 1);
                *ts = '\0';
            }
            strncpy(c->author, p + 7, sizeof(c->author) - 1);
        } else if (*p == '\0') {
            /* Blank line → rest is message */
            p = eol + 1;
            strncpy(c->message, p, sizeof(c->message) - 1);
            /* Strip trailing newline from message */
            size_t ml = strlen(c->message);
            while (ml > 0 && (c->message[ml-1] == '\n' || c->message[ml-1] == '\r'))
                c->message[--ml] = '\0';
            break;
        }

        p = eol + 1;
    }

    free(buf);
    return c;
}

/* ------------------------------------------------------------------ */
/* PROVIDED: commit_walk                                                 */
/* ------------------------------------------------------------------ */

void commit_walk(void)
{
    char hex[HASH_HEX];
    if (head_read(hex) < 0 || hex[0] == '\0') {
        printf("No commits yet.\n");
        return;
    }

    while (hex[0]) {
        char type[16];
        size_t size;
        unsigned char *data = object_read(hex, type, &size);
        if (!data) {
            fprintf(stderr, "Cannot read commit %s\n", hex);
            break;
        }

        Commit *c = commit_parse(data, size);
        free(data);
        if (!c) break;

        /* Pretty print */
        char timebuf[64];
        struct tm *tm = localtime(&c->timestamp);
        strftime(timebuf, sizeof(timebuf), "%Y-%m-%d %H:%M:%S", tm);

        printf("commit %s\n", hex);
        printf("Author: %s\n", c->author);
        printf("Date:   %s\n", timebuf);
        printf("\n    %s\n\n", c->message);

        strncpy(hex, c->parent, HASH_HEX - 1);
        hex[HASH_HEX - 1] = '\0';
        free(c);
    }
}

/* ------------------------------------------------------------------ */
/* commit_create (TODO — implemented here)                               */
/* ------------------------------------------------------------------ */

int commit_create(const char *message)
{
    /* 1. Build tree from index */
    char tree_hex[HASH_HEX];
    if (tree_from_index(tree_hex) < 0) {
        fprintf(stderr, "pes: failed to build tree from index\n");
        return -1;
    }

    /* 2. Read current HEAD (may be empty for first commit) */
    char parent_hex[HASH_HEX];
    if (head_read(parent_hex) < 0)
        parent_hex[0] = '\0';

    /* 3. Build the Commit struct */
    Commit c;
    memset(&c, 0, sizeof(c));
    strncpy(c.tree, tree_hex, HASH_HEX - 1);
    strncpy(c.parent, parent_hex, HASH_HEX - 1);
    strncpy(c.author, pes_author(), sizeof(c.author) - 1);
    c.timestamp = time(NULL);
    strncpy(c.message, message, sizeof(c.message) - 1);

    /* 4. Serialize */
    size_t sz;
    unsigned char *raw = commit_serialize(&c, &sz);
    if (!raw) {
        fprintf(stderr, "pes: failed to serialize commit\n");
        return -1;
    }

    /* 5. Write commit object */
    char commit_hex[HASH_HEX];
    int ret = object_write(OBJ_COMMIT, raw, sz, commit_hex);
    free(raw);
    if (ret < 0) {
        fprintf(stderr, "pes: failed to write commit object\n");
        return -1;
    }

    /* 6. Update HEAD ref */
    if (head_update(commit_hex) < 0) {
        fprintf(stderr, "pes: failed to update HEAD\n");
        return -1;
    }

    printf("[%s %.7s] %s\n", MAIN_BRANCH, commit_hex, message);
    return 0;
}
