#ifndef OBJECT_H
#define OBJECT_H

#include "pes.h"
#include <stddef.h>

/*
 * object_write — Store data in the content-addressable object store.
 *
 * type:    "blob", "tree", or "commit"
 * data:    raw bytes to store
 * size:    number of bytes in data
 * out_hex: caller-allocated buffer of at least HASH_HEX bytes;
 *          receives the NUL-terminated hex hash on success.
 *
 * Returns 0 on success, -1 on error.
 */
int object_write(const char *type, const unsigned char *data, size_t size,
                 char out_hex[HASH_HEX]);

/*
 * object_read — Retrieve an object from the store.
 *
 * hex:       64-char hex hash (NUL-terminated)
 * out_type:  buffer of at least 16 bytes; receives the object type string
 * out_size:  receives the size of the returned data
 *
 * Returns a heap-allocated buffer containing the raw data (after the header),
 * or NULL on error. Caller must free().
 */
unsigned char *object_read(const char *hex, char out_type[16], size_t *out_size);

/*
 * object_path — Fill buf with the filesystem path for a given hex hash.
 * buf must be at least MAX_PATH bytes.
 */
void object_path(const char *hex, char *buf, size_t buflen);

#endif /* OBJECT_H */
