#define _POSIX_C_SOURCE 200809L
#define _XOPEN_SOURCE   700

/*
 * pes.c — CLI entry point and command dispatch.
 * PROVIDED — do not modify.
 */

#include "pes.h"
#include "object.h"
#include "index.h"
#include "tree.h"
#include "commit.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <errno.h>
#include <dirent.h>

/* ------------------------------------------------------------------ */
/* pes_author                                                            */
/* ------------------------------------------------------------------ */

const char *pes_author(void)
{
    const char *a = getenv("PES_AUTHOR");
    return a ? a : "PES User <pes@localhost>";
}

/* ------------------------------------------------------------------ */
/* cmd_init                                                              */
/* ------------------------------------------------------------------ */

static int cmd_init(void)
{
    const char *dirs[] = {
        PES_DIR,
        OBJECTS_DIR,
        PES_DIR "/refs",
        REFS_DIR,
        NULL
    };
    for (int i = 0; dirs[i]; i++) {
        if (mkdir(dirs[i], 0755) < 0 && errno != EEXIST) {
            perror(dirs[i]);
            return 1;
        }
    }

    /* Write HEAD */
    FILE *f = fopen(HEAD_FILE, "w");
    if (!f) { perror(HEAD_FILE); return 1; }
    fprintf(f, "ref: refs/heads/%s\n", MAIN_BRANCH);
    fclose(f);

    printf("Initialized empty PES repository in ./%s/\n", PES_DIR);
    return 0;
}

/* ------------------------------------------------------------------ */
/* cmd_add                                                               */
/* ------------------------------------------------------------------ */

static int cmd_add(int argc, char *argv[])
{
    if (argc < 1) {
        fprintf(stderr, "usage: pes add <file>...\n");
        return 1;
    }

    Index idx;
    if (index_load(&idx) < 0) {
        fprintf(stderr, "pes: cannot load index\n");
        return 1;
    }

    int ret = 0;
    for (int i = 0; i < argc; i++) {
        if (index_add(&idx, argv[i]) < 0)
            ret = 1;
    }

    if (index_save(&idx) < 0) {
        fprintf(stderr, "pes: cannot save index\n");
        ret = 1;
    }
    index_free(&idx);
    return ret;
}

/* ------------------------------------------------------------------ */
/* cmd_status                                                            */
/* ------------------------------------------------------------------ */

/* Collect all files in the working directory recursively */
static void collect_files(const char *dir, char paths[][MAX_PATH], int *count, int max)
{
    DIR *d = opendir(dir);
    if (!d) return;
    struct dirent *de;
    while ((de = readdir(d)) && *count < max) {
        if (de->d_name[0] == '.') continue;
        char full[MAX_PATH];
        snprintf(full, sizeof(full), "%s/%s", dir, de->d_name);
        /* Strip leading "./" */
        const char *p = full;
        if (p[0] == '.' && p[1] == '/') p += 2;

        struct stat st;
        if (stat(full, &st) < 0) continue;
        if (S_ISDIR(st.st_mode)) {
            collect_files(full, paths, count, max);
        } else {
            strncpy(paths[*count], p, MAX_PATH - 1);
            (*count)++;
        }
    }
    closedir(d);
}

static int cmd_status(void)
{
    Index idx;
    if (index_load(&idx) < 0) {
        fprintf(stderr, "pes: cannot load index\n");
        return 1;
    }

    /* Collect working directory files */
    static char wdfiles[MAX_ENTRIES][MAX_PATH];
    int wdcount = 0;
    collect_files(".", wdfiles, &wdcount, MAX_ENTRIES);

    /* Staged: in index */
    printf("Staged changes:\n");
    int any = 0;
    for (size_t i = 0; i < idx.count; i++) {
        printf("  staged:     %s\n", idx.entries[i].path);
        any = 1;
    }
    if (!any) printf("  (nothing to show)\n");

    /* Unstaged: modified or deleted */
    printf("\nUnstaged changes:\n");
    any = 0;
    for (size_t i = 0; i < idx.count; i++) {
        FileStatus s = index_status(&idx, idx.entries[i].path);
        if (s == STATUS_MODIFIED) {
            printf("  modified:   %s\n", idx.entries[i].path);
            any = 1;
        } else if (s == STATUS_DELETED) {
            printf("  deleted:    %s\n", idx.entries[i].path);
            any = 1;
        }
    }
    if (!any) printf("  (nothing to show)\n");

    /* Untracked: in working dir but not in index */
    printf("\nUntracked files:\n");
    any = 0;
    for (int i = 0; i < wdcount; i++) {
        if (!index_find(&idx, wdfiles[i])) {
            printf("  untracked:  %s\n", wdfiles[i]);
            any = 1;
        }
    }
    if (!any) printf("  (nothing to show)\n");

    index_free(&idx);
    return 0;
}

/* ------------------------------------------------------------------ */
/* cmd_commit                                                            */
/* ------------------------------------------------------------------ */

static int cmd_commit(int argc, char *argv[])
{
    const char *msg = NULL;
    for (int i = 0; i < argc - 1; i++) {
        if (strcmp(argv[i], "-m") == 0) {
            msg = argv[i+1];
            break;
        }
    }
    if (!msg) {
        fprintf(stderr, "usage: pes commit -m <message>\n");
        return 1;
    }
    return commit_create(msg) < 0 ? 1 : 0;
}

/* ------------------------------------------------------------------ */
/* cmd_log                                                               */
/* ------------------------------------------------------------------ */

static int cmd_log(void)
{
    commit_walk();
    return 0;
}

/* ------------------------------------------------------------------ */
/* main                                                                  */
/* ------------------------------------------------------------------ */

int main(int argc, char *argv[])
{
    if (argc < 2) {
        fprintf(stderr, "usage: pes <command> [args]\n");
        fprintf(stderr, "Commands: init, add, status, commit, log\n");
        return 1;
    }

    const char *cmd = argv[1];

    if (strcmp(cmd, "init") == 0)
        return cmd_init();
    if (strcmp(cmd, "add") == 0)
        return cmd_add(argc - 2, argv + 2);
    if (strcmp(cmd, "status") == 0)
        return cmd_status();
    if (strcmp(cmd, "commit") == 0)
        return cmd_commit(argc - 2, argv + 2);
    if (strcmp(cmd, "log") == 0)
        return cmd_log();

    fprintf(stderr, "pes: unknown command '%s'\n", cmd);
    return 1;
}
